import ContactForm from "../components/jsx/ContactForm";

export default function ContactUs() {
  return (
    <div>
      <ContactForm />
    </div>
  );
}
