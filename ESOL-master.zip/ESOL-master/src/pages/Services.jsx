import FeatureSection from "../components/jsx/FeatureSection";
import FeaturesList from "../components/jsx/FeaturesList";
export default function Services() {
  return (
    <div>
      <FeatureSection />
      <FeaturesList />
    </div>
  );
}
